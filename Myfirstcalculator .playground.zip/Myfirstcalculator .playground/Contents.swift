import Cocoa

var str = "Hello, playground"



//Section One
var a = 3
var b = 5
var c = 688
var d = 3654
var e = 9
var f = 063
var g = 652
var h = 8392
var i = 40824
var j = 3
//section 2;

let calc1 = a/b
let calc2 = b*e
let calc3 = e/f
let calc4 = j * a
let calc5 = g / h
let calc6 = f*c
let calc7 = h+5
let calc8 = (f+3)/h
let calc9 = a*j+d
let calc10 = a + d + g + c
let calc11 = a/b+e
let calc12 = (a+c)/e


//Section 3

print(calc1)
print(calc2)
print(calc3)
print(calc4)
print(calc5)
print(calc6)
print(calc7)
print(calc8)
print(calc9)
print(calc10)
print(calc11)
print(calc12)









